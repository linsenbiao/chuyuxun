create
    definer = root@localhost procedure test_insert()
BEGIN 
DECLARE y BIGINT DEFAULT 1;
WHILE y<10000000
DO
INSERT INTO mmall_user(`username`, `password`, 
`email`, `phone`, `question`, `answer`, `role`, 
`wechat_openid`, `create_time`, `update_time`) 
VALUES ( y, '3BAD6AF0FA4B8B330D162E19938EE981',
 NULL, '13652739211', '问题', '答案', '0', 
NULL, '2018-05-18 09:32:57', '2018-05-18 09:32:57');

SET y=y+1; 
END WHILE ; 
commit; 
END;

